pip install flask requests
python Bridge.py
Read-Host -Prompt "Press Enter to exit" 